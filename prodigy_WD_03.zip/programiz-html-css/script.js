const boardElement = document.getElementById('board');
const statusText = document.getElementById('status');
let currentPlayer = 'X';
let board = Array(9).fill("");
let gameOver = false;
let mode = 'pvp';

const winPatterns = [
  [0,1,2], [3,4,5], [6,7,8],
  [0,3,6], [1,4,7], [2,5,8],
  [0,4,8], [2,4,6]
];

function createBoard() {
  boardElement.innerHTML = "";
  board = Array(9).fill("");
  for (let i = 0; i < 9; i++) {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    cell.dataset.index = i;
    cell.addEventListener('click', handleClick);
    boardElement.appendChild(cell);
  }
  currentPlayer = 'X';
  gameOver = false;
  statusText.textContent = `Current Player: ${currentPlayer}`;
}

function setMode(selectedMode) {
  mode = selectedMode;
  resetGame();
}

function handleClick(e) {
  const index = e.target.dataset.index;
  if (board[index] || gameOver) return;

  makeMove(index, currentPlayer);

  if (mode === 'ai' && currentPlayer === 'O' && !gameOver) {
    setTimeout(aiMove, 500);
  }
}

function makeMove(index, player) {
  board[index] = player;
  const cell = document.querySelector(`.cell[data-index='${index}']`);
  cell.textContent = player;

  if (checkWinner(player)) {
    statusText.textContent = `${player} Wins!`;
    gameOver = true;
  } else if (!board.includes("")) {
    statusText.textContent = "It's a Draw!";
    gameOver = true;
  } else {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    statusText.textContent = `Current Player: ${currentPlayer}`;
  }
}

function checkWinner(player) {
  return winPatterns.some(pattern =>
    pattern.every(index => board[index] === player)
  );
}

function aiMove() {
  // Simple AI: Pick random empty cell
  const emptyIndices = board.map((val, i) => val === "" ? i : null).filter(i => i !== null);
  const randIndex = emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
  makeMove(randIndex, 'O');
}

function resetGame() {
  createBoard();
}

createBoard();
